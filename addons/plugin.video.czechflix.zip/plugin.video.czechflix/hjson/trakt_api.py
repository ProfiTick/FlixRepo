# -*- coding: utf-8 -*-
import xbmc
import xbmcaddon
import xbmcgui
import time
from trakt import Trakt
from json import loads, dumps
import os

class TraktAPI(object):
    __client_id = "a90eef41c5b27bee38d96dfec60bbbc9c9facac553bc838fdbcaf9ae6a649d8c"
    __client_secret = "303564d8a49846867df34f0d0228aff124bc3acb25e078b80d9c554ecc93e31f"

    def __init__(self, addon_id='plugin.video.czechflix'):
        self.addon = xbmcaddon.Addon(id=addon_id)
        self.authorization = None
        Trakt.configuration.defaults.client(
            id=self.__client_id,
            secret=self.__client_secret
        )
        Trakt.on('oauth.token_refreshed', self.on_token_refreshed)
        Trakt.configuration.defaults.oauth(refresh=True)
        Trakt.configuration.defaults.http(retry=True, timeout=90)
        self._load_token()

    def _load_token(self):
        auth = self.addon.getSetting('trakt.authorization')
        if auth:
            try:
                self.authorization = loads(auth)
                Trakt.configuration.defaults.oauth.from_response(self.authorization, refresh=True)
            except Exception:
                self.authorization = None
        else:
            self.authorization = None

    def save_token(self):
        if self.authorization:
            self.addon.setSetting('trakt.authorization', dumps(self.authorization))
        else:
            self.addon.setSetting('trakt.authorization', '')

    def is_enabled(self):
        """Check if Trakt is enabled in settings"""
        return self.addon.getSettingBool('trakt.enabled')

    def is_authenticated(self):
        """Check if we have valid authorization"""
        if not self.is_enabled():
            return False
        return self.authorization is not None

    def login(self):
        """Authenticate with Trakt"""
        if not self.is_enabled():
            xbmcgui.Dialog().notification('Trakt', 'Trakt.tv není povolen v nastavení!', xbmcgui.NOTIFICATION_ERROR, 4000)
            return False
        
        with Trakt.configuration.http(timeout=90):
            code = Trakt['oauth/device'].code()
            if not code:
                xbmcgui.Dialog().notification('Trakt', 'Chyba připojení k Trakt.tv', xbmcgui.NOTIFICATION_ERROR, 4000)
                return False
            verification_url = code.get('verification_url')
            user_code = code.get('user_code')
            expires_in = code.get('expires_in', 900)
            interval = code.get('interval', 5)

            # Show the user the code and URL
            ok = xbmcgui.Dialog().ok(
                'Trakt.tv Přihlášení',
                f'1. Otevřete {verification_url}\n2. Zadejte kód: [B]{user_code}[/B]\n\nPo přihlášení se okno zavře.'
            )

            # Show a progress dialog while polling
            progress = xbmcgui.DialogProgress()
            progress.create('Trakt.tv', 'Čekání na autorizaci...')
            start = time.time()
            success = False
            token = None
            while time.time() - start < expires_in:
                if progress.iscanceled():
                    progress.close()
                    xbmcgui.Dialog().notification('Trakt', 'Přihlášení zrušeno.', xbmcgui.NOTIFICATION_ERROR, 4000)
                    return False
                try:
                    token = Trakt['oauth/device'].token(code['device_code'])
                    if token:
                        self.authorization = token
                        self.save_token()
                        username = self.get_user(update_setting=True)
                        progress.close()
                        if username:
                            xbmcgui.Dialog().ok('Trakt', f'Úspěšně přihlášeno k Trakt.tv jako {username}!')
                            xbmcgui.Dialog().notification('Trakt', f'Přihlášeno jako {username}', xbmcgui.NOTIFICATION_INFO, 4000)
                        else:
                            xbmcgui.Dialog().ok('Trakt', 'Autorizace úspěšná!')
                            xbmcgui.Dialog().notification('Trakt', 'Úspěšně přihlášeno k Trakt.tv!', xbmcgui.NOTIFICATION_INFO, 4000)
                        xbmc.executebuiltin('Addon.OpenSettings')
                        success = True
                        break
                except Exception:
                    pass
                xbmc.sleep(interval * 1000)
            if not success:
                progress.close()
                xbmcgui.Dialog().notification('Trakt', 'Kód vypršel, zkuste to znovu.', xbmcgui.NOTIFICATION_ERROR, 4000)
                return False
            return True

    def logout(self):
        self.authorization = None
        self.save_token()
        self.addon.setSetting('trakt.user', '')
        self.addon.setSetting('trakt.authorization', '')
        xbmcgui.Dialog().notification('Trakt', 'Odhlášeno z Trakt.tv', xbmcgui.NOTIFICATION_INFO, 3000)
        xbmc.executebuiltin('Addon.OpenSettings')

    def on_token_refreshed(self, response):
        self.authorization = response
        self.save_token()

    def get_user(self, update_setting=False):
        if not self.is_authenticated():
            if update_setting:
                self.addon.setSetting('trakt.user', '')
            return None
        try:
            with Trakt.configuration.oauth.from_response(self.authorization):
                with Trakt.configuration.http(retry=True):
                    result = Trakt['users/settings'].get()
                    if result and 'user' in result:
                        username = result['user'].get('username', '')
                        if update_setting:
                            self.addon.setSetting('trakt.user', username)
                        return username
        except Exception:
            if update_setting:
                self.addon.setSetting('trakt.user', '')
            return None
        return None

    def sync_watched(self):
        if not self.is_authenticated():
            xbmcgui.Dialog().notification('Trakt', 'Nejste přihlášeni k Trakt.tv', xbmcgui.NOTIFICATION_ERROR, 4000)
            return False
            
        # Show progress dialog
        progress = xbmcgui.DialogProgress()
        progress.create('Trakt.tv', 'Synchronizace sledovaných položek...')
        
        try:
            with Trakt.configuration.oauth.from_response(self.authorization):
                with Trakt.configuration.http(retry=True):
                    # Fetch watched movies and shows
                    progress.update(25, 'Načítání filmů...')
                    movies = Trakt['sync/watched'].movies()
                    
                    progress.update(50, 'Načítání seriálů...')
                    shows = Trakt['sync/watched'].shows()
                    
                    # Process to local database or favorites
                    progress.update(75, 'Zpracování dat...')
                    # Here you would update local data with watched status
                    # For now, we just count items
                    
                    movie_count = len(movies) if movies else 0
                    show_count = len(shows) if shows else 0
                    
                    progress.close()
                    
                    # Success notification with counts
                    xbmcgui.Dialog().notification(
                        'Trakt', 
                        f'Synchronizováno: {movie_count} filmů, {show_count} seriálů', 
                        xbmcgui.NOTIFICATION_INFO, 
                        4000
                    )
                    return True
        except Exception as e:
            progress.close()
            xbmcgui.Dialog().notification('Trakt', f'Chyba synchronizace: {str(e)}', xbmcgui.NOTIFICATION_ERROR, 4000)
            return False 